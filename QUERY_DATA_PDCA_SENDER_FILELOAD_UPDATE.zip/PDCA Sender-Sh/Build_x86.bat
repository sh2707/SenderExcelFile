@echo off
setlocal
set ROOT=%~dp0
set MSBUILD="%ProgramFiles(x86)%\Microsoft Visual Studio\2022\BuildTools\MSBuild\Current\Bin\MSBuild.exe"
if not exist %MSBUILD% set MSBUILD="%ProgramFiles%\Microsoft Visual Studio\2022\BuildTools\MSBuild\Current\Bin\MSBuild.exe"
if not exist %MSBUILD% set MSBUILD=msbuild
%MSBUILD% "%ROOT%PDCA Sender.csproj" /t:Build /p:Configuration=Release /p:Platform=x86
if errorlevel 1 (
  echo Build failed.
  pause
  exit /b 1
)
echo Build completed.
echo EXE: %ROOT%bin\x86\Release\PDCA Sender.exe
pause
