using PDCA_Sender.Services;
using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using Microsoft.Win32;
using System.Xml.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using Path = System.IO.Path;

namespace PDCA_Sender
{
    public partial class MainWindow : Window
    {
        private readonly TcpService _tcpService;
        private readonly BarcodeQueryService _barcodeQueryService;
        private bool _busy;
        private string _lastAutoPanelSn = string.Empty;

        private const int RequiredBarcodeCount = 8;

        // After every enabled barcode got "OK success", the screen is cleared (headings only) after this delay
        // so the operator can still see the green result. Set to 0 for an immediate clear.
        private const int ResetDelayMs = 1000;

        private static readonly Brush GreenBrush = MakeBrush(0, 100, 0);
        private static readonly Brush RedBrush = MakeBrush(190, 0, 0);
        private static readonly Brush SendingBrush = MakeBrush(245, 245, 245);

        private readonly bool[] _sendOk = new bool[RequiredBarcodeCount + 1];
        private int _dataVersion;
        private List<string> _loadedFileData = new List<string>();
        private int _fileSuccessCount;
        private int _fileFailedCount;
        private System.Diagnostics.Stopwatch _sendWatch = new System.Diagnostics.Stopwatch();

        private static Brush MakeBrush(byte r, byte g, byte b)
        {
            var brush = new SolidColorBrush(Color.FromRgb(r, g, b));
            brush.Freeze();
            return brush;
        }

        // Green tab = bold white text.
        private static void ApplyGreen(Control c)
        {
            c.Background = GreenBrush;
            c.Foreground = Brushes.White;
            c.FontWeight = FontWeights.Bold;
        }

        private static void ApplyPlain(Control c, FontWeight weight)
        {
            c.Background = Brushes.White;
            c.Foreground = Brushes.Black;
            c.FontWeight = weight;
        }

        private TextBox BarcodeBox(int i) { return FindName("txtBarcodeData" + i) as TextBox; }
        private Button GenerateBtn(int i) { return FindName("btnGenerate" + i) as Button; }
        private Button SendBtn(int i) { return FindName("btnSend" + i) as Button; }
        private TextBox ResponseBox(int i) { return FindName("txtResponse" + i) as TextBox; }
        private TextBox TemplateBox(int i) { return FindName("txtTemplate" + i) as TextBox; }

        // SEND buttons are green (bold white text) in both Manual and Auto mode; disabled ones stay plain/grey.
        private void ApplySendButtonStyles()
        {
            for (int i = 1; i <= RequiredBarcodeCount; i++)
            {
                var button = SendBtn(i);
                if (button == null) continue;
                if (button.IsEnabled) ApplyGreen(button);
                else ApplyPlain(button, FontWeights.Normal);
            }
        }

        // Clears every tab back to its heading only.
        private void ResetAllData()
        {
            _dataVersion++;
            for (int i = 1; i <= RequiredBarcodeCount; i++)
            {
                _sendOk[i] = false;

                var template = TemplateBox(i);
                if (template != null) template.Clear();

                var barcode = BarcodeBox(i);
                if (barcode != null)
                {
                    barcode.Text = "Barcode Data Result " + i;
                    ApplyPlain(barcode, FontWeights.Normal);
                }

                var generate = GenerateBtn(i);
                if (generate != null) ApplyPlain(generate, FontWeights.Normal);

                var response = ResponseBox(i);
                if (response != null)
                {
                    response.Text = "Server Response data " + i;
                    ApplyPlain(response, FontWeights.Bold);
                }
            }
            if (txtBarcodeResult != null) txtBarcodeResult.Clear();
        }

        // When every enabled barcode (1 for MLB SN, 8 otherwise) got OK success, clear all tabs.
        private async void ScheduleResetIfComplete()
        {
            int active = SelectedSnType == "MLB SN" ? 1 : RequiredBarcodeCount;
            for (int i = 1; i <= active; i++)
                if (!_sendOk[i]) return;

            int version = _dataVersion;
            if (ResetDelayMs > 0)
                await Task.Delay(ResetDelayMs);

            // New data arrived / another action started meanwhile -> do not wipe it.
            if (version != _dataVersion) return;
            ResetAllData();
        }

        private string ConfigPath => Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Config", "server.txt");
        private string TemplatePath => Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Templates", "pdca_template.txt");
        private string LogFolder => Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Logs");

        public MainWindow()
        {
            InitializeComponent();
            _tcpService = new TcpService();
            _barcodeQueryService = new BarcodeQueryService();
            LoadServerConfig();
            LoadTemplates();
            // Apply the selected SN type state after all template controls are initialized.
            // This keeps PANEL/JIG controls enabled on startup while preserving MLB behavior.
            SetBarcode2To8ControlsEnabled(SelectedSnType != "MLB SN");
        }

        private void LoadServerConfig()
        {
            try
            {
                if (!File.Exists(ConfigPath))
                {
                    Directory.CreateDirectory(Path.GetDirectoryName(ConfigPath));
                    File.WriteAllLines(ConfigPath, new[]
                    {
                        "IP=127.0.0.1",
                        "PORT=56378",
                        "URL=http://127.0.0.1/MLBAutoInterface/mlbauto.do?GET_BARCODE_PRE_DISTRIBUTE&info_type=JIG&upload_info={PANEL_SN}",
                        "METHOD=POST"
                    });
                }

                foreach (string rawLine in File.ReadAllLines(ConfigPath))
                {
                    string line = rawLine.Trim();
                    if (line.StartsWith("IP=", StringComparison.OrdinalIgnoreCase))
                        txtIp.Text = line.Substring(3).Trim();
                    else if (line.StartsWith("PORT=", StringComparison.OrdinalIgnoreCase))
                        txtPort.Text = line.Substring(5).Trim();
                    else if (line.StartsWith("URL=", StringComparison.OrdinalIgnoreCase))
                        txtBarcodeUrl.Text = line.Substring(4).Trim();
                    else if (line.StartsWith("METHOD=", StringComparison.OrdinalIgnoreCase))
                        cmbRequestMethod.SelectedIndex = line.Substring(7).Trim().Equals("POST", StringComparison.OrdinalIgnoreCase) ? 1 : 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Config Error:\n" + ex.Message, "PDCA Sender", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void SaveConfig_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(ConfigPath));
                File.WriteAllLines(ConfigPath, new[]
                {
                    "IP=" + txtIp.Text.Trim(),
                    "PORT=" + txtPort.Text.Trim(),
                    "URL=" + txtBarcodeUrl.Text.Trim(),
                    "METHOD=" + (((cmbRequestMethod.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "GET"))
                });
                txtStatus.Text = "Configuration saved.";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unable to save configuration:\n" + ex.Message, "PDCA Sender", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void LoadTemplates()
        {
            try
            {
                if (!File.Exists(TemplatePath))
                {
                    MessageBox.Show("PDCA template file not found:\n" + TemplatePath, "PDCA Sender", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                string template = File.ReadAllText(TemplatePath);
                txtTemplate1.Text = template;
                txtTemplate2.Text = template;
                txtTemplate3.Text = template;
                txtTemplate4.Text = template;
                txtTemplate5.Text = template;
                txtTemplate6.Text = template;
                txtTemplate7.Text = template;
                txtTemplate8.Text = template;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Template Error:\n" + ex.Message, "PDCA Sender", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private async void LoadFile_Click(object sender, RoutedEventArgs e)
        {
            if (SelectedSnType != "MLB SN")
            {
                MessageBox.Show("File loading is available for MLB SN only.", "PDCA Sender", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            var dialog = new OpenFileDialog { Title = "Load MLB SN data", Filter = "Supported files (*.csv;*.txt;*.xml;*.xlsx)|*.csv;*.txt;*.xml;*.xlsx|All files (*.*)|*.*" };
            if (dialog.ShowDialog(this) != true) return;
            try
            {
                string content;
                if (Path.GetExtension(dialog.FileName).Equals(".xlsx", StringComparison.OrdinalIgnoreCase))
                {
                    MessageBox.Show("For offline compatibility, save the Excel sheet as CSV or XML and load it again.", "PDCA Sender", MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }
                content = File.ReadAllText(dialog.FileName);
                if (Path.GetExtension(dialog.FileName).Equals(".xml", StringComparison.OrdinalIgnoreCase))
                {
                    try { content = string.Join(Environment.NewLine, XDocument.Parse(content).Descendants().Select(x => x.Value)); } catch { }
                }
                _loadedFileData = Regex.Matches(content, @"(?<![A-Za-z0-9])[A-Za-z0-9]{18}(?![A-Za-z0-9])")
                    .Cast<Match>().Select(m => m.Value).Distinct().ToList();
                if (_loadedFileData.Count == 0)
                {
                    txtStatus.Text = "No 18-character alphanumeric serial numbers found in the selected file.";
                    MessageBox.Show(txtStatus.Text, "Load File", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }
                _fileSuccessCount = 0; _fileFailedCount = 0;
                txtBarcodeResult.Text = "Loaded file: " + Path.GetFileName(dialog.FileName) + " | Total: " + _loadedFileData.Count;
                txtStatus.Text = "Loaded " + _loadedFileData.Count + " MLB SN records. Press Get Data to process in Manual mode, or select Auto.";
                if (rbAuto.IsChecked == true) await ProcessLoadedFileAsync();
            }
            catch (Exception ex) { txtStatus.Text = "File load failed: " + ex.Message; MessageBox.Show(txtStatus.Text, "Load File", MessageBoxButton.OK, MessageBoxImage.Error); }
        }

        private async Task ProcessLoadedFileAsync()
        {
            if (_busy || _loadedFileData == null || _loadedFileData.Count == 0) return;
            _busy = true; SetBusy(true); _fileSuccessCount = 0; _fileFailedCount = 0;
            var outcomes = new List<string>();
            _sendWatch.Restart();
            try
            {
                string template = File.ReadAllText(TemplatePath);
                for (int n = 0; n < _loadedFileData.Count; n++)
                {
                    string sn = _loadedFileData[n];
                    txtPanelSn.Text = sn;
                    txtBarcodeData1.Text = sn; ApplyGreen(txtBarcodeData1);
                    txtTemplate1.Text = GeneratePdcaData(template, sn, sn); SetBarcodeText(txtTemplate1, sn); ApplyGreen(btnGenerate1);
                    txtResponse1.Text = "Sending " + (n + 1) + "/" + _loadedFileData.Count;
                    try
                    {
                        string response = await _tcpService.SendAsync(txtIp.Text.Trim(), int.Parse(txtPort.Text.Trim()), txtTemplate1.Text);
                        bool ok = IsResponseSuccessful(response);
                        SetResponse(txtResponse1, response, ok);
                        if (ok) { _fileSuccessCount++; WriteLog(sn, new[] { sn }, "TCP_OK: " + SanitizeLogValue(response)); outcomes.Add(sn + " - SUCCESS"); }
                        else { _fileFailedCount++; outcomes.Add(sn + " - FAILED: " + SanitizeLogValue(response)); }
                    }
                    catch (Exception ex) { _fileFailedCount++; SetResponse(txtResponse1, "ERROR: " + ex.Message, false); outcomes.Add(sn + " - FAILED: " + ex.Message); }
                    txtStatus.Text = "File progress " + (n + 1) + "/" + _loadedFileData.Count + " | Success: " + _fileSuccessCount + " | Failed: " + _fileFailedCount;
                    await Task.Yield();
                }
                _sendWatch.Stop();
                txtBarcodeResult.Text = string.Join(Environment.NewLine, outcomes);
                txtStatus.Text = "Completed " + _loadedFileData.Count + " records | Success: " + _fileSuccessCount + " | Failed: " + _fileFailedCount + " | Speed: " + (_sendWatch.Elapsed.TotalSeconds > 0 ? (_loadedFileData.Count / _sendWatch.Elapsed.TotalSeconds).ToString("0.00") : "0") + " records/sec";
            }
            finally { _busy = false; SetBusy(false); }
        }

        private void MainWindow_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            var result = MessageBox.Show("Are you sure you want to close PDCA Sender?", "Confirm Exit", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (result != MessageBoxResult.Yes) e.Cancel = true;
        }

        private async void GetData_Click(object sender, RoutedEventArgs e)
        {
            if (SelectedSnType == "MLB SN" && _loadedFileData != null && _loadedFileData.Count > 0) await ProcessLoadedFileAsync();
            else await QueryAndProcessAsync(false);
        }

        private void rbManual_Checked(object sender, RoutedEventArgs e)
        {
            ApplySendButtonStyles();
        }

        private async void rbAuto_Checked(object sender, RoutedEventArgs e)
        {
            ApplySendButtonStyles();
            if (SelectedSnType == "MLB SN" && _loadedFileData != null && _loadedFileData.Count > 0) { await ProcessLoadedFileAsync(); return; }

            if (_busy)
                return;

            string panelSn = txtPanelSn.Text.Trim();
            if (!IsValidSn(panelSn))
                return;

            if (string.Equals(panelSn, _lastAutoPanelSn, StringComparison.OrdinalIgnoreCase))
                return;

            _lastAutoPanelSn = panelSn;
            await QueryAndProcessAsync(true);
        }

        private async void txtPanelSn_TextChanged(object sender, TextChangedEventArgs e)
        {
            // Auto mode: as soon as a complete 23-character Panel SN is scanned/typed,
            // automatically query the server and continue with the existing Auto workflow.
            if (_busy || rbAuto.IsChecked != true)
                return;

            string panelSn = txtPanelSn.Text.Trim();
            if (!IsValidSn(panelSn))
                return;

            if (string.Equals(panelSn, _lastAutoPanelSn, StringComparison.OrdinalIgnoreCase))
                return;

            _lastAutoPanelSn = panelSn;
            await QueryAndProcessAsync(true);
        }

        private async void txtPanelSn_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key != Key.Enter || _busy)
                return;

            e.Handled = true;
            await QueryAndProcessAsync(rbAuto.IsChecked == true);
        }

        private async Task QueryAndProcessAsync(bool autoTriggered)
        {
            if (_busy)
                return;

            string panelSn = txtPanelSn.Text.Trim();
            if (string.IsNullOrWhiteSpace(panelSn))
            {
                MessageBox.Show("Scan / enter Panel SN first.", "PDCA Sender", MessageBoxButton.OK, MessageBoxImage.Warning);
                txtPanelSn.Focus();
                return;
            }

            if (autoTriggered && !IsValidSn(panelSn))
            {
                txtStatus.Text = "Auto mode waiting for a valid " + GetRequiredSnLength() + "-character " + SelectedSnType + ".";
                return;
            }

            if (string.IsNullOrWhiteSpace(txtBarcodeUrl.Text))
            {
                MessageBox.Show("Barcode Query URL is empty.", "PDCA Sender", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            _busy = true;
            SetBusy(true);
            ResetAllData(); // new data -> start from clean headings (also cancels any pending clear)
            txtStatus.Text = "Querying barcode data for Panel SN: " + panelSn;

            try
            {
                if (SelectedSnType == "MLB SN")
                {
                    if (!Regex.IsMatch(panelSn, @"^[A-Za-z0-9]{18}$"))
                    {
                        txtStatus.Text = "MLB SN must contain 18 alphanumeric characters.";
                        return;
                    }
                    txtBarcodeResult.Text = panelSn;
                    txtTemplate1.Text = GeneratePdcaData(File.ReadAllText(TemplatePath), panelSn, panelSn);
                    SetBarcodeText(txtTemplate1, panelSn);
                    txtBarcodeData1.Text = panelSn;
                    ApplyGreen(txtBarcodeData1);
                    ApplyGreen(btnGenerate1);
                    txtStatus.Text = "MLB SN template generated.";
                    if (rbAuto.IsChecked == true) await SendTemplateAsync(txtTemplate1, txtResponse1, 1);
                    else txtStatus.Text += " Ready for manual SEND.";
                    return;
                }
                string rawResult = await _barcodeQueryService.GetAsync(txtBarcodeUrl.Text.Trim(), panelSn, (cmbRequestMethod.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "GET");
                txtBarcodeResult.Text = rawResult.Trim();

                string[] barcodes = ExtractBarcodes(rawResult);
                for (int i = 1; i <= RequiredBarcodeCount; i++)
                {
                    var resultBox = BarcodeBox(i);
                    var generateButton = GenerateBtn(i);
                    if (resultBox != null)
                    {
                        if (i <= barcodes.Length)
                        {
                            resultBox.Text = barcodes[i - 1];
                            ApplyGreen(resultBox);
                        }
                        else
                        {
                            resultBox.Text = "Barcode Data Result " + i;
                            ApplyPlain(resultBox, FontWeights.Normal);
                        }
                    }
                    if (generateButton != null) ApplyPlain(generateButton, FontWeights.Normal);
                }
                if (barcodes.Length != RequiredBarcodeCount)
                {
                    ClearBarcodeFields();
                    txtStatus.Text = "Barcode query failed: expected 8 barcode results, found " + barcodes.Length + ".";
                    MessageBox.Show(
                        "Expected 8 barcode results.\n\nActual response:\n" + rawResult,
                        "Barcode Query Result",
                        MessageBoxButton.OK,
                        MessageBoxImage.Warning);
                    return;
                }

                txtTemplate1.Text = GeneratePdcaData(File.ReadAllText(TemplatePath), barcodes[0], panelSn);
                txtTemplate2.Text = GeneratePdcaData(File.ReadAllText(TemplatePath), barcodes[1], panelSn);
                txtTemplate3.Text = GeneratePdcaData(File.ReadAllText(TemplatePath), barcodes[2], panelSn);
                txtTemplate4.Text = GeneratePdcaData(File.ReadAllText(TemplatePath), barcodes[3], panelSn);
                txtTemplate5.Text = GeneratePdcaData(File.ReadAllText(TemplatePath), barcodes[4], panelSn);
                txtTemplate6.Text = GeneratePdcaData(File.ReadAllText(TemplatePath), barcodes[5], panelSn);
                txtTemplate7.Text = GeneratePdcaData(File.ReadAllText(TemplatePath), barcodes[6], panelSn);
                txtTemplate8.Text = GeneratePdcaData(File.ReadAllText(TemplatePath), barcodes[7], panelSn);

                SetBarcodeText(txtTemplate1, barcodes[0]);
                SetBarcodeText(txtTemplate2, barcodes[1]);
                SetBarcodeText(txtTemplate3, barcodes[2]);
                SetBarcodeText(txtTemplate4, barcodes[3]);
                SetBarcodeText(txtTemplate5, barcodes[4]);
                SetBarcodeText(txtTemplate6, barcodes[5]);
                SetBarcodeText(txtTemplate7, barcodes[6]);
                SetBarcodeText(txtTemplate8, barcodes[7]);
                for (int i = 1; i <= RequiredBarcodeCount; i++)
                {
                    var generateButton = GenerateBtn(i);
                    if (generateButton != null) ApplyGreen(generateButton);
                }

                txtStatus.Text = "8 barcode results received and 8 templates generated.";

                if (rbAuto.IsChecked == true)
                    await SendAllAsync();
            }
            catch (Exception ex)
            {
                txtStatus.Text = "Barcode query error: " + ex.Message;
                MessageBox.Show("Barcode Query Error:\n" + ex.Message, "PDCA Sender", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                _busy = false;
                SetBusy(false);
                txtPanelSn.Focus();
                if (rbAuto.IsChecked == true)
                    txtPanelSn.SelectAll();
            }
        }

        private string SelectedSnType => (cmbSnType.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "PANEL SN";

        private bool IsValidPanelSn(string panelSn)
        {
            if (panelSn == null) return false;
            return IsValidSn(panelSn);
        }

        private int GetRequiredSnLength()
        {
            switch (SelectedSnType)
            {
                case "MLB SN": return 18;
                case "JIG SN": return 14;
                default: return 23;
            }
        }

        private bool IsValidSn(string sn)
        {
            if (string.IsNullOrWhiteSpace(sn)) return false;
            return Regex.IsMatch(sn, @"^[A-Za-z0-9]{" + GetRequiredSnLength() + @"}$");
        }

        private void cmbSnType_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (txtBarcodeUrl == null || txtTemplate1 == null) return;
            bool mlb = SelectedSnType == "MLB SN";
            txtBarcodeUrl.IsEnabled = !mlb;
            txtBarcodeResult.IsEnabled = !mlb;
            txtTemplate1.IsEnabled = true;
            txtTemplate2.IsEnabled = !mlb; txtTemplate3.IsEnabled = !mlb;
            txtTemplate4.IsEnabled = !mlb; txtTemplate5.IsEnabled = !mlb;
            txtTemplate6.IsEnabled = !mlb; txtTemplate7.IsEnabled = !mlb; txtTemplate8.IsEnabled = !mlb;
            SetBarcode2To8ControlsEnabled(!mlb);
            ResetAllData();
            _lastAutoPanelSn = string.Empty;
        }

        private void SetBarcode2To8ControlsEnabled(bool enabled)
        {
            var templateBoxes = new[] { txtTemplate2, txtTemplate3, txtTemplate4, txtTemplate5, txtTemplate6, txtTemplate7, txtTemplate8 };
            var responseBoxes = new[] { txtResponse2, txtResponse3, txtResponse4, txtResponse5, txtResponse6, txtResponse7, txtResponse8 };
            var barcodeBoxes = new[] { txtBarcodeData2, txtBarcodeData3, txtBarcodeData4, txtBarcodeData5, txtBarcodeData6, txtBarcodeData7, txtBarcodeData8 };
            var generateButtons = new[] { btnGenerate2, btnGenerate3, btnGenerate4, btnGenerate5, btnGenerate6, btnGenerate7, btnGenerate8 };
            var sendButtons = new[] { btnSend2, btnSend3, btnSend4, btnSend5, btnSend6, btnSend7, btnSend8 };

            foreach (var box in templateBoxes)
                if (box != null) box.IsEnabled = enabled;
            foreach (var box in responseBoxes)
                if (box != null) box.IsEnabled = enabled;
            foreach (var box in barcodeBoxes)
                if (box != null) box.IsEnabled = enabled;
            foreach (var button in generateButtons)
                if (button != null) button.IsEnabled = enabled;
            foreach (var button in sendButtons)
                if (button != null) button.IsEnabled = enabled;

            ApplySendButtonStyles();
        }

        private string[] ExtractBarcodes(string response)
        {
            if (string.IsNullOrWhiteSpace(response))
                return new string[0];

            // Primary format: GVD123456789123456 (18 characters).
            string[] matches = Regex.Matches(response, @"\bGVD[A-Za-z0-9]{15}\b", RegexOptions.IgnoreCase)
                .Cast<Match>()
                .Select(m => m.Value.Trim())
                .Take(RequiredBarcodeCount)
                .ToArray();

            if (matches.Length == RequiredBarcodeCount)
                return matches;

            // Fallback: comma/newline/space separated values.
            string[] tokens = response
                .Split(new[] { ',', ';', '\r', '\n', '\t', ' ' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(x => x.Trim().Trim('"', '\'', '[', ']', '{', '}'))
                .Where(x => x.StartsWith("GVD", StringComparison.OrdinalIgnoreCase))
                .Take(RequiredBarcodeCount)
                .ToArray();

            return tokens;
        }

        private string GeneratePdcaData(string template, string barcode, string panelSn)
        {
            string[] lines = template.Split(new[] { "\r\n", "\n" }, StringSplitOptions.None);

            for (int i = 0; i < lines.Length; i++)
            {
                string line = lines[i];
                if (string.IsNullOrWhiteSpace(line))
                    continue;

                int firstAtIndex = line.IndexOf('@');
                if (firstAtIndex > 0)
                    line = barcode + line.Substring(firstAtIndex);

                line = line.Replace("{BARCODE}", barcode)
                           .Replace("{PANEL_SN}", panelSn)
                           .Replace("{CARRIER_SN}", panelSn);

                line = ReplaceFieldValue(line, "Carrier_SN", panelSn);
                line = ReplaceFieldValue(line, "pallet_sn", panelSn);

                lines[i] = line;
            }

            return string.Join("\r\n", lines);
        }

        private string ReplaceFieldValue(string line, string key, string value)
        {
            string token = "@" + key + "@";
            int index = line.IndexOf(token, StringComparison.OrdinalIgnoreCase);
            if (index < 0)
                return line;

            int valueStart = index + token.Length;
            int nextAt = line.IndexOf('@', valueStart);
            if (nextAt < 0)
                return line.Substring(0, valueStart) + value;

            return line.Substring(0, valueStart) + value + line.Substring(nextAt);
        }

        private void SetBarcodeText(TextBox templateBox, string barcode)
        {
            if (templateBox.Text.Length > 0)
                templateBox.Text = templateBox.Text.Replace("SAMPLE_MLB", barcode);
        }

        private async Task SendAllAsync()
        {
            await SendTemplateAsync(txtTemplate1, txtResponse1, 1);
            if (!IsResponseSuccessful(txtResponse1.Text)) return;
            await SendTemplateAsync(txtTemplate2, txtResponse2, 2);
            if (!IsResponseSuccessful(txtResponse2.Text)) return;
            await SendTemplateAsync(txtTemplate3, txtResponse3, 3);
            if (!IsResponseSuccessful(txtResponse3.Text)) return;
            await SendTemplateAsync(txtTemplate4, txtResponse4, 4);
            if (!IsResponseSuccessful(txtResponse4.Text)) return;
            await SendTemplateAsync(txtTemplate5, txtResponse5, 5);
            if (!IsResponseSuccessful(txtResponse5.Text)) return;
            await SendTemplateAsync(txtTemplate6, txtResponse6, 6);
            if (!IsResponseSuccessful(txtResponse6.Text)) return;
            await SendTemplateAsync(txtTemplate7, txtResponse7, 7);
            if (!IsResponseSuccessful(txtResponse7.Text)) return;
            await SendTemplateAsync(txtTemplate8, txtResponse8, 8);
        }

        private async Task SendTemplateAsync(TextBox templateBox, TextBox responseBox, int index)
        {
            string data = templateBox.Text;
            if (string.IsNullOrWhiteSpace(data))
            {
                txtStatus.Text = "Barcode data " + index + " is empty. Get Data first.";
                return;
            }

            _dataVersion++; // cancels any pending auto-clear
            _sendOk[index] = false;
            string panelSn = txtPanelSn.Text.Trim();

            int port;
            if (!int.TryParse(txtPort.Text.Trim(), out port))
            {
                SetResponse(responseBox, "FAILED: Invalid TCP port.", false);
                return;
            }

            try
            {
                responseBox.Text = "Sending...";
                responseBox.Background = SendingBrush;
                responseBox.Foreground = Brushes.Black;

                string response = await _tcpService.SendAsync(txtIp.Text.Trim(), port, data);
                bool success = IsResponseSuccessful(response);
                SetResponse(responseBox, response, success);
                txtStatus.Text = success
                    ? "Barcode data " + index + " TCP send completed."
                    : "Barcode data " + index + " TCP server returned an error.";

                if (success)
                {
                    _sendOk[index] = true;
                    // Only OK/success results are written to the log.
                    WriteLog(panelSn, new[] { GetBarcodeFromTemplate(data) }, "TCP_OK: " + SanitizeLogValue(response));
                    ScheduleResetIfComplete();
                }
            }
            catch (Exception ex)
            {
                SetResponse(responseBox, "ERROR: " + ex.Message, false);
                txtStatus.Text = "Barcode data " + index + " TCP send failed.";
            }
        }

        private string GetBarcodeFromTemplate(string template)
        {
            Match match = Regex.Match(template ?? "", @"\bGVD[A-Za-z0-9]{15}\b", RegexOptions.IgnoreCase);
            if (match.Success) return match.Value;

            // MLB SN: the barcode is the text before the first '@' of the first line.
            string firstLine = (template ?? "").Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries).FirstOrDefault() ?? "";
            int at = firstLine.IndexOf('@');
            return at > 0 ? firstLine.Substring(0, at) : "";
        }

        private bool IsResponseSuccessful(string response)
        {
            if (string.IsNullOrWhiteSpace(response))
                return false;
            string value = response.Trim().ToUpperInvariant();
            return value.Contains("{OK:SUCCESS}") || value.Contains("OK:SUCCESS") || value.Contains("SUCCESS") || value.Contains("PASS");
        }

        private void SetResponse(TextBox box, string response, bool success)
        {
            box.Text = response;
            if (success)
            {
                ApplyGreen(box);
            }
            else
            {
                box.Background = RedBrush;
                box.Foreground = Brushes.White;
                box.FontWeight = FontWeights.Normal;
            }
        }

        private string SanitizeLogValue(string value)
        {
            return (value ?? string.Empty)
                .Replace("\r", " ")
                .Replace("\n", " ")
                .Replace(",", ";")
                .Trim();
        }

        private void ClearBarcodeFields()
        {
            ResetAllData();
        }

        private void SetBusy(bool busy)
        {
            txtPanelSn.IsEnabled = !busy;
            txtBarcodeUrl.IsEnabled = !busy;
        }

        private void Generate1_Click(object sender, RoutedEventArgs e) { GenerateOne(txtTemplate1, 1); }
        private void Generate2_Click(object sender, RoutedEventArgs e) { GenerateOne(txtTemplate2, 2); }
        private void Generate3_Click(object sender, RoutedEventArgs e) { GenerateOne(txtTemplate3, 3); }
        private void Generate4_Click(object sender, RoutedEventArgs e) { GenerateOne(txtTemplate4, 4); }
        private void Generate5_Click(object sender, RoutedEventArgs e) { GenerateOne(txtTemplate5, 5); }
        private void Generate6_Click(object sender, RoutedEventArgs e) { GenerateOne(txtTemplate6, 6); }
        private void Generate7_Click(object sender, RoutedEventArgs e) { GenerateOne(txtTemplate7, 7); }
        private void Generate8_Click(object sender, RoutedEventArgs e) { GenerateOne(txtTemplate8, 8); }

        private void GenerateOne(TextBox box, int index)
        {
            if (SelectedSnType == "MLB SN")
            {
                string sn = txtPanelSn.Text.Trim();
                if (!Regex.IsMatch(sn, @"^[A-Za-z0-9]{18}$"))
                {
                    txtStatus.Text = "MLB SN must contain 18 alphanumeric characters.";
                    return;
                }
                _dataVersion++;
                _sendOk[1] = false;
                txtBarcodeResult.Text = sn;
                box.Text = GeneratePdcaData(File.ReadAllText(TemplatePath), sn, sn);
                SetBarcodeText(box, sn);
                txtBarcodeData1.Text = sn;
                ApplyGreen(txtBarcodeData1);
                ApplyGreen(btnGenerate1);
                txtStatus.Text = "MLB SN template generated.";
                return;
            }

            string[] barcodes = ExtractBarcodes(txtBarcodeResult.Text);
            if (barcodes.Length != RequiredBarcodeCount)
            {
                MessageBox.Show("Get 8 barcode results first.", "PDCA Sender", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            box.Text = GeneratePdcaData(File.ReadAllText(TemplatePath), barcodes[index - 1], txtPanelSn.Text.Trim());
            SetBarcodeText(box, barcodes[index - 1]);
            _dataVersion++;
            _sendOk[index] = false;
            var generateButton = GenerateBtn(index);
            if (generateButton != null) ApplyGreen(generateButton);
            txtStatus.Text = "Template for barcode data " + index + " generated.";
        }

        private async void Send1_Click(object sender, RoutedEventArgs e) { await SendTemplateAsync(txtTemplate1, txtResponse1, 1); }
        private async void Send2_Click(object sender, RoutedEventArgs e) { await SendTemplateAsync(txtTemplate2, txtResponse2, 2); }
        private async void Send3_Click(object sender, RoutedEventArgs e) { await SendTemplateAsync(txtTemplate3, txtResponse3, 3); }
        private async void Send4_Click(object sender, RoutedEventArgs e) { await SendTemplateAsync(txtTemplate4, txtResponse4, 4); }
        private async void Send5_Click(object sender, RoutedEventArgs e) { await SendTemplateAsync(txtTemplate5, txtResponse5, 5); }
        private async void Send6_Click(object sender, RoutedEventArgs e) { await SendTemplateAsync(txtTemplate6, txtResponse6, 6); }
        private async void Send7_Click(object sender, RoutedEventArgs e) { await SendTemplateAsync(txtTemplate7, txtResponse7, 7); }
        private async void Send8_Click(object sender, RoutedEventArgs e) { await SendTemplateAsync(txtTemplate8, txtResponse8, 8); }

        private async void TestConnection_Click(object sender, RoutedEventArgs e)
        {
            int port;
            if (!int.TryParse(txtPort.Text.Trim(), out port))
            {
                MessageBox.Show("Invalid TCP port.", "PDCA Sender", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            bool connected = await _tcpService.TestConnectionAsync(txtIp.Text.Trim(), port);
            txtStatus.Text = connected ? "TCP connection successful." : "TCP connection failed.";
            var connectionButton = sender as Button;
            if (connectionButton != null) connectionButton.Background = new SolidColorBrush(connected ? Color.FromRgb(0, 150, 70) : Color.FromRgb(190, 35, 35));
            MessageBox.Show(connected ? "Server connection successful." : "Unable to connect to server.", "PDCA Sender", MessageBoxButton.OK, connected ? MessageBoxImage.Information : MessageBoxImage.Warning);
        }

        private void WriteLog(string panelSn, string[] barcodes, string result)
        {
            try
            {
                Directory.CreateDirectory(LogFolder);
                string file = Path.Combine(LogFolder, DateTime.Now.ToString("yyyy-MM-dd") + ".txt");
                string data = string.Join(",", barcodes ?? new string[0]);
                File.AppendAllText(file, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "," + panelSn + "," + data + "," + result + Environment.NewLine);
            }
            catch
            {
                // Logging must never stop the PDCA workflow.
            }
        }
    }
}
