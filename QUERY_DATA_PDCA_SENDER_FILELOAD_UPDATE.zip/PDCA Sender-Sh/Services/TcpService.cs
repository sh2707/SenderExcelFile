﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace PDCA_Sender.Services
{
        public class TcpService
        {
            public async Task<bool> TestConnectionAsync(
                string ip,
                int port)
            {
                try
                {
                    using (TcpClient client = new TcpClient())
                    {
                        var connectTask =
                            client.ConnectAsync(ip, port);

                        var timeoutTask =
                            Task.Delay(3000);

                        var completedTask =
                            await Task.WhenAny(
                                connectTask,
                                timeoutTask);

                        if (completedTask == timeoutTask)
                            return false;

                        return client.Connected;
                    }
                }
                catch
                {
                    return false;
                }
            }


            public async Task<string> SendAsync(
                string ip,
                int port,
                string data)
            {
                using (TcpClient client = new TcpClient())
                {
                    client.NoDelay = true;

                    // Literal IP: connect directly (no DNS lookup). ConfigureAwait(false): no UI-thread hops while sending.
                    IPAddress address;
                    if (IPAddress.TryParse(ip, out address))
                        await client.ConnectAsync(address, port).ConfigureAwait(false);
                    else
                        await client.ConnectAsync(ip, port).ConfigureAwait(false);

                    NetworkStream stream =
                        client.GetStream();

                    byte[] sendData =
                        Encoding.UTF8.GetBytes(data);

                    await stream.WriteAsync(
                        sendData,
                        0,
                        sendData.Length).ConfigureAwait(false);

                    byte[] buffer =
                        new byte[8192];

                    int received =
                        await stream.ReadAsync(
                            buffer,
                            0,
                            buffer.Length).ConfigureAwait(false);

                    if (received == 0)
                        return "No response received.";

                    string response =
                        Encoding.UTF8.GetString(
                            buffer,
                            0,
                            received);

                    return response;
                }
            }
        }
    
}
